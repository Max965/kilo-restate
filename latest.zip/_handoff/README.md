# Software Factory latest.zip

Review transport only. Exact changed source bytes are under `_source/`; Semantic Operator chain files are under `_chain/`; Git/diff/completeness receipts are under `_handoff/`.

This is review transport. Optional Factory/report notes are recorded inside `_handoff/`; they do not make the source return fail.
