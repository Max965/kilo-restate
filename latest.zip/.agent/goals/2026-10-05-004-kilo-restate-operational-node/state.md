# Current state

**Outcome:** IN_PROGRESS; no A01–G04 matrix result is available yet.

**Active subject:** `subjects/first-pi-operational-node`, source path `operational-node/`.

**Accepted facts:** stakeholder approved the Kilo-owned `operational-node/` layout; installed Restate SDK 1.17.2 and exact maintained Pi checkout are available; R1–R4 setup readiness is captured under `iterations/01/actors/orchestrator-01/turns/001/captures/`. Product code and acceptance tests have not been written.

**Next action:** write a failing stable-identity/effect-identity assertion test, observe the intended red, then implement its smallest contract before the service/driver.

**Closure:** run the full A01–G04 matrix, record a status and evidence pointer for each of all 32 checks, review the retained diff, restore temporary runtime state, and return exactly one of ACHIEVED/PARTIAL/BLOCKED without claiming production readiness.
