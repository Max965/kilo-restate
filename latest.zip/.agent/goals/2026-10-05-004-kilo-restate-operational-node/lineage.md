# Lineage

- Goal: `2026-10-05-004-kilo-restate-operational-node` (new retained implementation increment).
- Active subject: `first-pi-operational-node`, physical source home `operational-node/` in the Kilo Restate repository.
- Source baseline: `main` / `dd30babdc4305a1e54516e03a37146c7c018f7bf`, tree `ab3f6f0ac227ef75c0f60e07ef2ee39b7198c401`; see `iterations/01/BASELINE.env`.
- Normative architecture/method and 32-check acceptance: exact user handoff `GOAL.md`, SHA-256 above. The stakeholder approved the proposed source layout with `yes approved` before implementation.
- Reused evidence only: goal 002 physically characterized ordinary Pi `RpcClient`, native tools, Restate gates/effects and same-host process/session reopen; its report explicitly leaves cancellation and native child lineage unproven. Goal 003 is an evidence-only Codex frontier and is not a driver in this subject.
- Frozen surroundings: Restate server/source and the maintained Pi checkout/provider/core. No upstream modifications or new dependency are permitted.
- Iteration 001 is the first implementation/proof attempt. Keep prior goal evidence and root `latest.zip` intact until the new review package is ready.
