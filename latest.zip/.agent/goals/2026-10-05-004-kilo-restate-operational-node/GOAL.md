EXECUTION_MODE: PI_LEGACY
PI_REVIEW_PROFILE: DIRECT

Do this work yourself; do not launch or delegate to any sub-agents.

# SUBJECT

Kilo Restate operational node — first production-shaped Restate + ordinary Pi implementation.

Canonical subject:

`/home/miles/repos/agent-harnesses/kilo-restate`

This is no longer another perimeter survey.

The Restate + ordinary Pi architecture has already been physically characterised.

This run must **materialise the smallest production-shaped vertical slice and execute a fixed acceptance matrix end-to-end**.

Do not stop at the first local problem.

---

# GOAL

Create a new goal using the repository's established `.agent/goals/` convention and copy this GOAL text verbatim:

**GOAL: Materialise and deterministically prove the first production-shaped Kilo asynchronous operational node using Restate as the authoritative durable outer runtime and ordinary maintained Pi as the first replaceable coding-agent driver: place the implementation in the natural Kilo-owned integration boundary without modifying Restate or Pi core; provide stable operation identity, Pi process/session control, pre-effect Restate gates, Restate-owned tool effects, structured lifecycle visibility, semantic settlement, restart recovery and bounded cancellation/child control; and execute the complete acceptance matrix so every independent requirement returns PASS, FAIL or BLOCKED rather than terminating the run at the first residual.**

---

# COMMITTED ARCHITECTURE

Treat this as the active architecture baseline for this increment:

```text
SOFTWARE FACTORY
       |
       v
REST﻿ATE
authoritative outer operation
       |
       | Kilo operational-node service
       |
       +-------------------------------+
       |                               |
       v                               v
common operation contract          driver: pi
identity / state / gates        RpcClient + extension
effects / lineage              session + event mapping
settlement                           |
       |                             v
       +-------------------------- ordinary Pi
                                      |
                                      v
                           Pi provider/model runtime
```

Ownership law:

## RESTATE OWNS

- logical operation identity;
- durable admission;
- outer journal;
- outer retry/re-entry;
- policy/gate decisions;
- durable effects;
- operational parent/child relationships;
- outer cancellation state;
- terminal operational settlement.

## PI OWNS

- coding-agent loop;
- provider/model implementation;
- transcript/session semantics;
- native tool contract;
- agent turn semantics;
- inner `agent_settled` truth.

## KILO ADAPTER OWNS

Only semantic impedance:

- Restate run ↔ Pi session/process mapping;
- Restate decision ↔ Pi interception;
- Pi tool contract ↔ Restate effect;
- Pi lifecycle/event ↔ Kilo/Restate projection;
- Pi settlement ↔ Restate terminal settlement;
- cancellation and child-request translation where required.

Do not create a second workflow engine.

Do not use Pi Durable underneath Restate.

Do not modify Restate server core.

Do not modify Pi core/provider/model implementation.

---

# 1. PRE-FLIGHT — KEEP THIS SHORT

Before adding production source, establish the actual local topology.

Inspect:

- Kilo Restate repository top level;
- package/workspace manifests;
- existing production source versus `probe/`;
- existing build/test commands;
- Git status;
- existing Restate server/container launch path;
- existing Pi checkout and exact revision;
- existing reusable probe components.

Return a short topology decision:

```text
KILO_RESTATE_ROOT:
PACKAGE_MODEL:
EXISTING_PRODUCTION_HOME:
EXISTING_PROBE_HOME:
CHOSEN_OPERATIONAL_NODE_HOME:
WHY_THIS_IS_NATIVE:
UPSTREAM_RESTATE_MODIFIED: NO
UPSTREAM_PI_MODIFIED: NO
```

Do not stop after reporting this.

### Placement rule

Prefer the repository's existing package/module convention.

If there is no genuine production package convention, create a clean Kilo-owned operational-node source area rather than promoting code inside `probe/`.

Logical structure should remain approximately:

```text
operational-node/
    contract/
    restate/
    drivers/
        pi/
    projection/
```

Actual directories should follow the repository's native TypeScript/workspace convention.

---

# 2. SETUP READINESS

Before deeper coding, prove the substrate can actually be exercised.

Check:

### R1 Restate available
Start or reuse the already-proven local Restate server through the cheapest existing path.

Do not rebuild Restate from source.

Do not spend the run repairing Podman/container infrastructure unless no independent work can continue.

Verify ingress and admin/query endpoint response.

### R2 Pi available
Start the pinned maintained Pi checkout in RPC mode with a trivial Kilo extension loaded.

Verify RPC request/reply.

### R3 disposable workspace
Create/reset a deterministic disposable coding workspace.

### R4 deterministic model path
Use Pi's Faux provider or equivalent already-proven deterministic native provider for acceptance.

A real network model/provider is **non-gating**.

If an already-configured live model works immediately, one smoke may be performed after deterministic acceptance.

Do not make auth/provider troubleshooting control this run.

For any failed readiness item:

```text
STATUS: FAIL | BLOCKED
CAUSE:
EVIDENCE:
INDEPENDENT_WORK_CAN_CONTINUE: YES | NO
```

Continue wherever `YES`.

---

# 3. BUILD THE MINIMUM RETAINED IMPLEMENTATION

Promote only the smallest useful portions of the successful probe into real Kilo-owned source.

Do not copy the probe wholesale.

Implement:

## A. Common operational-node contract

Minimum stable types for:

- operation/run ID;
- runtime driver ID;
- inner session ID;
- status;
- result;
- cancellation;
- tool/effect identity;
- parent operation where relevant.

Keep this harness-neutral enough that a future Codex driver can implement it.

Do not invent a generic agent framework.

## B. Restate operational-node service

Own:

- keyed durable operation admission;
- durable run state;
- driver invocation;
- gate/decision calls;
- effect calls;
- terminal result;
- status/attach surface.

## C. Pi driver

Reuse:

- Pi `RpcClient`;
- Pi session ID/session directory facilities;
- Pi extension hooks;
- native Pi tool operation interfaces.

## D. Kilo Pi extension

Own only:

- pre-tool interception;
- decision call into Restate;
- fail-closed translation;
- bounded lifecycle event forwarding/correlation where required.

## E. Restate-backed native Pi effects

Reuse Pi's native schemas/result formatting.

Route the actual operation implementation through Restate-owned effect handlers.

Do not duplicate Pi's `read/write/edit/bash` schemas.

---

# 4. DETERMINISTIC ACCEPTANCE MATRIX

Create an executable verifier.

It must run every independent check and produce machine-readable output.

Each check returns exactly:

`PASS | FAIL | BLOCKED | SKIPPED_DEPENDENCY`

Do not abort the matrix on the first failure.

Final output must include:

```text
CHECK_ID
STATUS
OBSERVED
EXPECTED
EVIDENCE_POINTER
BLOCKS
```

Prefer a TypeScript verifier consistent with the implementation unless repository conventions strongly indicate another medium.

The verifier's final process exit may be non-zero when required checks fail, but only **after all independent checks have run**.

---

# ACCEPTANCE CHECKLIST

## A — substrate and identity

### A01 Restate starts
Ingress and admin/query surfaces respond.

### A02 Operational-node service registers
Restate can discover/invoke the Kilo service.

### A03 Pi RPC starts with Kilo extension
Exact maintained Pi runs; no Pi source modification.

### A04 Stable operation admission
Submit operation with stable logical key.

Duplicate submission must attach/resolve to the same Restate operation identity, not create a second logical run.

### A05 Pi session mapping
One Restate operation maps to a recorded Pi session ID/storage locator.

---

## B — actual coding-agent lifecycle

### B01 Prompt reaches ordinary Pi
Run one deterministic Pi turn through the real ordinary Pi loop.

### B02 Pi turn/lifecycle visible
Capture at least the authoritative turn/start lifecycle necessary for the operational contract.

### B03 Authoritative Pi settlement
Observe `agent_settled`.

### B04 Restate settles afterwards
Outer operation becomes terminal only after inner Pi settlement/result has been accepted.

---

## C — pre-effect control

Use harmless disposable operations.

### C01 `read`
Pi requests native `read`.

Kilo extension intercepts before execution.

Restate decision precedes effect.

ALLOW executes.

### C02 `write`
Same proof for `write`.

### C03 `edit`
Same proof for `edit`.

### C04 `bash`
Same proof for harmless `bash`.

### C05 DENY
Restate returns DENY for one harmless attempted effect.

Physical effect must not occur.

### C06 Restate decision failure
Simulate bounded gate error/unavailability.

Pi must fail closed.

Physical effect must not occur.

These are mandatory control checks.

Logging after execution does not satisfy them.

---

## D — durable effects

### D01 Stable tool/effect identity
Derive a stable effect identity from outer run/session/tool call/operation.

### D02 Restate owns effect invocation
The effect appears as actual Restate durable work rather than only as an extension callback/log event.

### D03 Result returns to Pi
Pi receives its normal native result shape.

### D04 Result correlates to operation
A controller can correlate:

```text
Restate run
↔ Pi session
↔ Pi tool call
↔ Restate effect invocation
↔ result
```

without parsing prose logs.

---

## E — recovery

### E01 Kill Pi child after durable decision
After Restate has committed ALLOW but before harmless effect execution, kill the Pi RPC child.

### E02 Same outer operation survives
Restate retains the original operation identity.

### E03 Pi session reopens
New Pi process reopens the recorded session.

### E04 Durable decision is reused
Do not ask a fresh semantic policy question for the same logical tool call.

### E05 Operation reaches settlement
Pi eventually `agent_settled`; same Restate operation completes.

Do not infer exactly-once external effects from this.

Use an idempotent/safe fixture.

Cross-host recovery is not required in this increment.

---

## F — cancellation/control

Attempt the complete path once:

```text
Restate operation cancellation
        ↓
Kilo driver
        ↓
RpcClient.abort / Pi interruption
        ↓
outer cancelled/interrupted state
```

Checks:

### F01 controller requests cancellation
### F02 Pi receives actual interrupt/abort
### F03 late result behavior is explicit
### F04 Restate final state is deterministic

If one aspect is blocked by current APIs, record it and continue.

Do not spend the entire run perfecting cancellation.

---

## G — operational child

Build/prove only the smallest child operation mechanism.

Target law:

```text
Pi requests child through controlled tool
        ↓
Restate context creates keyed child operation
        ↓
Restate owns child ID
        ↓
parent/child relation is queryable
        ↓
result/child ID returns to Pi
```

Checks:

### G01 child request crosses controlled Pi tool boundary
### G02 child Restate identity created
### G03 parent/child relation queryable
### G04 child terminal/result can return to parent

Do not build Pi-native subagent orchestration.

If native Restate causal lineage proves materially harder than the rest of the slice, mark the exact item `BLOCKED`, retain correlation by stable IDs temporarily, and continue all independent checks.

---

# 5. DEBUG / VISIBILITY PROOF

We want a usable first debug surface now.

Do not build a bespoke UI.

Prove that a controller/operator can obtain, by stable operation ID:

- current Restate status;
- Pi session identity;
- current/last turn;
- tool request;
- durable ALLOW/DENY;
- durable tool/effect invocation;
- tool result;
- retries/restarts;
- final Pi settlement;
- final Restate settlement;
- parent/child relation where implemented.

Use Restate's own invocation/journal/query surfaces as the source of durable truth.

### Restate UI

If the existing Restate UI can be launched through a trivial existing command/container, launch it and inspect one specimen.

Capture whether the operation's durable run/gates/effects/retries/children are visible.

If UI startup requires unrelated infrastructure repair, mark:

`UI_BLOCKED`

and continue using Admin/SQL/journal proof.

Do not let UI setup block the operational-node implementation.

Do not add Langfuse in this increment.

Do not build a VS Code extension in this increment.

---

# 6. ONE COMMAND TO RUN, ONE COMMAND TO VERIFY

By the end, provide repository-native deterministic commands for:

## Start/dev

Starts or clearly instructs how to start:

- Restate dependency;
- Kilo operational-node service.

Pi may be spawned per operation by the driver.

## Verify

Runs the acceptance specimen/matrix from a clean disposable workspace.

Do not require manual editing of IDs between steps.

Do not require opening browser UI for verification.

---

# 7. BLOCKER LAW

This is critical.

Do not return merely because one acceptance item is difficult.

For each blocker:

1. isolate it;
2. record exact failure/evidence;
3. mark the affected check `BLOCKED`;
4. identify which later checks depend on it;
5. skip only those dependent checks;
6. continue every independent check.

Only terminate early if:

```text
GLOBAL_BLOCKER = TRUE
```

meaning no meaningful independent acceptance work can continue without destructive action, unavailable authority/credentials, or changing the committed architecture.

A difficult local issue is not a global blocker.

Do not redesign architecture merely to clear a local blocker.

---

# 8. REPRESENTATION QUALITY

This is retained source, not another disposable probe.

Before closure:

- remove duplicated exploratory machinery;
- keep reusable native Pi/Restate calls direct;
- keep system-specific adapter code thin;
- do not retain probe-only Faux logic inside production modules;
- keep deterministic fixtures under test/evidence support;
- classify meaningful custom seams:

`NATIVE_NECESSARY | ESCAPE_HATCH | UNJUSTIFIED`

Any `ESCAPE_HATCH` or `UNJUSTIFIED` seam must be highlighted in the return.

---

# 9. EXPLICIT NON-GOALS

Do not:

- implement Codex driver;
- integrate Pi Durable;
- modify Restate server source;
- modify Pi source/provider runtime;
- solve distributed cross-host Pi session storage;
- claim globally exactly-once arbitrary effects;
- build Langfuse integration;
- build custom UI;
- build VS Code extension;
- build generalized orchestration framework;
- replace Software Factory controller logic.

This increment establishes the physical operational node skeleton only.

---

# REQUIRED RETURN

Start with a compact acceptance table:

| Check | Status | Observed | Evidence |
|---|---|---|---|

Include **every A01–G04 check**.

Then:

## ARCHITECTURE MATERIALISED
Actual retained module/file layout and why it is the native Kilo Restate home.

## END-TO-END SPECIMEN
Exact sequence:

```text
controller
→ Restate admission
→ Kilo operational node
→ Pi RPC + extension
→ gate
→ Restate effect
→ Pi result
→ agent_settled
→ Restate settlement
```

with real IDs.

## DEBUG RESULT
What an operator can currently see using Restate-native surfaces.

## RECOVERY RESULT
What survived the Pi-child restart.

## CANCELLATION RESULT

## CHILD RESULT

## CODE DELTA
Only retained production source and deterministic verification machinery.

## SEAM CLASSIFICATION
`NATIVE_NECESSARY | ESCAPE_HATCH | UNJUSTIFIED`

## PARKED BLOCKERS
Each blocker with dependent checks and why independent work continued.

## RESIDUALS FOR NEXT ITERATION
Only items that remain after the complete acceptance matrix.

## FINAL RESULT

Use exactly one:

`ACHIEVED`
- all architecture-critical A–E checks pass and the retained implementation is coherent; F/G may have explicitly parked bounded residuals if they do not undermine basic control/settlement.

`PARTIAL`
- useful retained operational node exists but one or more architecture-critical A–E checks fail/block.

`BLOCKED`
- a genuine global blocker prevented material implementation/testing.

Do not call the implementation production-ready.

Stop after completing the complete matrix and returning the evidence.