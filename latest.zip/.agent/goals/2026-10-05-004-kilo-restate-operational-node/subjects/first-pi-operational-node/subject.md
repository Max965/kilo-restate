# Subject: First Pi operational node

## Artefact

Retained Kilo-owned TypeScript source at `/home/miles/repos/agent-harnesses/kilo-restate/operational-node/`, with a deterministic verifier and root npm commands. This is the first physical Restate + ordinary maintained Pi operational-node slice, not a probe promotion or production-readiness claim.

## Accepted world

- Restate Workflow owns one stable logical operation, durable admission/re-entry, gates, effect invocations, parent/child operations, and terminal operational settlement.
- Ordinary maintained Pi owns the agent loop, native tool schemas/results, session format and `agent_settled` truth. The driver uses its exported `RpcClient` and extension hooks.
- Kilo owns only the semantic bridge between them. Reuse installed Restate/Pi APIs; add no dependency and modify neither upstream.

## Mutable artefact

Only Kilo-owned files in `operational-node/`, root `package.json`/README, and this goal's evidence/report tree. Keep the previous goal artifacts and root `latest.zip` recoverable.

## Frozen surroundings and explicit boundaries

Restate server/source, maintained Pi source/provider/model implementation, credentials/configuration and unrelated evidence are frozen. Use the deterministic Faux provider, local Restate and disposable workspaces. No sub-agents, live-model debugging, Pi Durable, Codex driver, custom UI, Langfuse, VS Code integration, cross-host recovery, or exactly-once arbitrary-effect claim.

## Closure proof

The repository command must run every independent A01–G04 check and emit exactly `PASS`, `FAIL`, `BLOCKED`, or `SKIPPED_DEPENDENCY`, including observed/expected values, evidence pointer and dependency blockers. Check Restate-native journal/query surfaces for identity, gate/effect, lifecycle, recovery, cancellation and child facts. Continue after local failures; do not call the result production-ready.
