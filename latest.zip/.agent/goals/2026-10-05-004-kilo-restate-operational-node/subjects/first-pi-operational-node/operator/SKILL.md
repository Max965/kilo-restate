---
name: first-pi-operational-node-operator
description: Draft operating notes for this Kilo-owned Restate + maintained Pi operational-node subject.
---

# First Pi operational-node operator notes

Status: VALIDATED for the deterministic local Pi acceptance specimen; not a production deployment or security approval. Final full matrix: `iterations/01/evidence/operational-node/runs/2026-10-05T18-51-32.479Z-1293602/acceptance-matrix.json` (32 PASS).

## Ownership

- Use Restate Workflow identity and journal as the outer durable authority.
- Start/control ordinary maintained Pi through its `RpcClient`; use Pi's session ID/path and `agent_settled` as the inner truth.
- Await Kilo's Restate gate before any native tool implementation; route native Pi operation callbacks to Restate-owned effect handlers.
- Correlate by operation ID, Restate invocation ID, Pi session ID, tool-call ID and effect ID. Treat logs as aids, not durable truth.

## Local proof rules

- Use the exact pinned Pi source checkout and Faux provider; never call a network model in the acceptance matrix.
- Use a fresh disposable workspace/session directory for each specimen. Preserve stable operation keys when testing duplicate submission and same-host process recovery.
- Run the repository verifier to completion even when one check fails. Every A01–G04 item needs an explicit status and an evidence pointer.
- Keep Restate server and Pi source unmodified. Restore any service/container that the run temporarily starts to its captured original state.

## Known boundaries to retain in reports

- The acceptance specimen proves same-host Pi process/session reopen, bounded RPC cancellation, and native Restate parent/child lineage; it does not prove cross-host recovery.
- Restate journaling does not establish exactly-once behavior for arbitrary external effects; retain effect idempotency boundaries.
- Restate UI shows the durable operation/effect journals and a child parent-link; the gate decision payload and per-Pi-process attempts are not fully rendered. Use the structured Kilo event stream and Restate SQL/journal evidence for those details.
- Local unsigned ingress/service access is not a production security boundary; document required network restriction/identity configuration rather than claiming readiness.
