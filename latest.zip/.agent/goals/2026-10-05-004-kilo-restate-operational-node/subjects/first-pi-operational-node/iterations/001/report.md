# First Pi operational-node report

OUTCOME: PROVEN

**Outcome:** ACHIEVED for the deterministic local acceptance scope; not a production deployment or security approval.

## Physical acceptance

Fresh full matrix run `2026-10-05T18-51-32.479Z-1293602`: **32 PASS, 0 FAIL, 0 BLOCKED, 0 SKIPPED_DEPENDENCY**. Every A01–G04 row is present in [`acceptance-matrix.json`](../../../../iterations/01/evidence/operational-node/runs/2026-10-05T18-51-32.479Z-1293602/acceptance-matrix.json). The verifier completed each independent scenario and exited 0; per-scenario event histories, effects, SQL journals, child lineage, service logs, and cleanup are alongside it.

Evidence highlights:

- Pi checkout `b2b5c42f6138b73ec4b2f49ec0ca468800f88586`, unmodified; Restate 1.7.13 / SDK 1.17.2.
- Stable duplicate admission returns the same Restate invocation; normal Pi RPC produces an existing session file and settles before the outer operation.
- `read`, `write`, `edit`, and harmless `bash` all show ALLOW before each underlying Restate effect; the native edit changed the disposable file. DENY and gate failure perform no physical effect.
- Nine core tool-effect invocations have completed Restate `Command: Run` journal entries and return native-shaped Pi results with structured correlation.
- Recovery kills Pi after durable ALLOW: killed process ID `1295432`; process `1295879` reopens the same Pi session; driver-attempt IDs and effect IDs are distinct/stable as required; the original Restate invocation settles `RECOVERY_SETTLED`. This is same-host recovery only.
- Cancellation interrupts the Pi RPC wait and settles Restate as cancelled. A child operation returns through Pi; Restate SQL proves native parent invocation linkage.

## Retained implementation

Kilo-owned TypeScript lives under `operational-node/`. It uses Restate Workflow/Virtual Object services for operation state, gates, effects, event projection and bounded child relay; ordinary maintained Pi `RpcClient` and its extension remain the inner agent/tool/session boundary. No Pi or Restate source was changed, and no dependency was added. `package.json` provides `operational-node`, `test:operational-node`, `typecheck:operational-node`, and `verify:operational-node`; the deterministic test path uses Pi Faux. `README.md` documents service startup and the one-command full verifier. Root `.gitignore` excludes `.agent/goals/` from ordinary source status; review packaging explicitly carries the evidence chain.

RUN-01, RUN-02, and RUN-03 are retained unchanged as diagnostic evidence. They exposed Restate promise-combinator/gate-wire defects, followed by two verifier defects (native edit decomposes to access/read/write; retry event IDs collided) and one expected-newline typo. Those corrections were made in Kilo-owned source/verifier; RUN-04 reran the complete matrix and is the normative result. The old pre-implementation `iterations/01/evidence/operational-node/acceptance-matrix.json` is retained, not treated as this result.

## Operator UI and cleanup

A headed browser inspected the existing Restate 1.7.13 UI; captures are under `iterations/01/evidence/operational-node/ui-*`. The UI shows the succeeded outer invocation and journal timeline, separate gate/effect invocations under stable IDs, and a succeeded child with its `Invoked by` parent link. The gate result expansion reports `Decoding error`; the UI does not enumerate Pi process retries/IDs as distinct outer journal entries. Those details are established by structured Kilo events and Restate SQL/journal evidence, not the UI. After the verifier removed its deployment, the UI still showed retained invocation journals but correctly reported the deployment metadata missing.

The verifier's run-04 cleanup receipt reports deployment deletion HTTP 202 and absence, service exit by SIGTERM, and container stopped (it was stopped before the run). The UI-only inspection briefly started the same original Restate container, captured its before/started/after allowlisted state, closed the browser, and returned it to exited state. The scoped post-close process scan found no agent-browser, Pi CLI, verifier, or Kilo service process. The prior `latest.zip` SHA-256 was preserved until final package review.

## Boundaries and residuals

- This proves one local host / Faux provider specimen, not cross-host recovery, live-model behavior, multi-tenant load, or production deployment readiness.
- Do not claim exactly-once arbitrary filesystem/process effects. External actions still require idempotency/transaction boundaries.
- The Restate UI is useful but incomplete for semantic gate/retry details; SQL plus the structured event projection is the operator truth source.
- Local unsigned ingress and the adapter's OS permissions are not a security boundary. Production requires authenticated service access and OS/container-level workspace/process isolation.
- Historical Codex approval/control and same-thread resume evidence remain unproven and are outside this Pi acceptance matrix. Formal Software Factory provenance/clean-baseline receipts are also unavailable; execution remained PI_LEGACY/DIRECT, a process-profile deviation rather than a substrate failure.

## Reproduction

```sh
npm run test:operational-node
npm run typecheck:operational-node
npm run typecheck
npm run verify:operational-node
```

The acceptance verifier starts/reuses and restores the existing `kilo-restate-pi-lifecycle` container; it does not create a missing container. See the repository README for the one-time Podman setup.
