YOU ARE: orchestrator-01
ROLE: ORCHESTRATOR
PARENT_ACTOR: FACTORY
ACTOR_BOX: .agent/goals/2026-10-05-004-kilo-restate-operational-node/iterations/01/actors/orchestrator-01
ACTOR_TURN: 001
TURN_BOX: .agent/goals/2026-10-05-004-kilo-restate-operational-node/iterations/01/actors/orchestrator-01/turns/001
ASSIGNMENT: .agent/goals/2026-10-05-004-kilo-restate-operational-node/iterations/01/actors/orchestrator-01/turns/001/ASSIGNMENT.md
COMMON_AUTHORITY: .agent/goals/2026-10-05-004-kilo-restate-operational-node/GOAL.md + .agent/goals/2026-10-05-004-kilo-restate-operational-node/iterations/01/ITERATION.md
RECEIVED_INSTRUCTION_SHA256: 71bd4e04e121b1473d384f7a92ce7c4c419968d3968169ff3253f3c39d5ee406
CRITICAL_DIRECTIVES_READ: NONE (the exact handoff contains no CRITICAL_DIRECTIVES block)

RUN_KIND: IMPLEMENTATION (legacy handoff normalized to IMPLEMENTATION)
GOAL_ID: 2026-10-05-004-kilo-restate-operational-node
GOAL_STATUS: NEW
ITERATION: 01
CONTINUES_FROM: NONE
PI_REVIEW_PROFILE: DIRECT
FEATURE_ID: kilo-restate-operational-node
FEATURE: Materialize the smallest production-shaped Kilo-owned Restate + ordinary Pi operational node and execute the complete A01-G04 matrix.
QUALITY_BAR: Deterministic, physically exercised, all independent matrix checks run, no upstream source edits, no production-ready claim.
EXECUTABLE_DESIGN_ID: NONE (the handoff supplies a committed architecture and acceptance matrix, but no separately identified machine artifact)
EXECUTABLE_DESIGN_REVISION: NONE
OPERATOR_METHOD_ID: NONE (the handoff supplies explicit implementation, readiness, acceptance, blocker and return instructions, but no separately identified method artifact)
OPERATOR_METHOD_REVISION: NONE
RUN_QUESTION: Can the requested production-shaped vertical slice be materialized in the natural Kilo-owned home and physically prove A01-G04 with every independent check reported?
CURRENT_PROBLEM_CLASS: ARTEFACT_REALISATION
CURRENT_METHOD_CLASS: SOURCE_INSPECTION then REUSE_EXISTING_PROBES, TEST-FIRST MINIMAL IMPLEMENTATION, and DETERMINISTIC INTEGRATION_PROOF
CLASS_OBJECTIVE: Inspect local topology and prior accepted evidence; resolve the natural Kilo source boundary; implement only the requested adapter/service; write the executable all-check verifier before production code; run all independent A01-G04 acceptance checks and preserve precise statuses/evidence; perform a bounded root-only closure pass.
DURABLE_PROBLEM_STATE: Baseline captured at dd30babdc4305a1e54516e03a37146c7c018f7bf, tree ab3f6f0ac227ef75c0f60e07ef2ee39b7198c401, clean primary worktree. Prior committed probe evidence exists and is not equivalent to this new end-to-end slice.
ACCEPTANCE_RELEVANT_TO_THIS_CLASS: All A01-G04 checks, topology/setup evidence, physical deterministic path, observable IDs and ownership, no upstream modifications, retained source location, status completeness, report/package integrity.
RETURN_CONDITIONS: Complete every independent check or mark only dependent checks SKIPPED_DEPENDENCY; stop on genuine global blocker or stable frontier/controller decision; do not redesign the committed ownership law; do not claim production readiness; no sub-agents; do not commit.

Constraints: Restate owns durable outer state/gates/effects/lineage/cancellation/settlement; Pi owns its agent loop/session/tool semantics; Kilo translates. Do not modify Restate or Pi, do not use Pi Durable underneath Restate, do not add a generalized orchestration system, and preserve existing work. Use deterministic native Pi/Faux behavior for acceptance and safe disposable workspace/effects. Continue independent checks after local failures.

Model/runtime note: ACTUAL_MODEL=openai-codex/gpt-6-luna with PI_REASONING_LEVEL=max. This identity is outside the installed Semantic Operator default pool; no current-session model-switch surface was supplied, and no child/new model session is authorized. Record this process deviation without changing user-directed DIRECT execution.
