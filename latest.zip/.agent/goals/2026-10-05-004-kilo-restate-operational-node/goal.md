# Stable goal

**GOAL:** Materialise and deterministically prove the first production-shaped Kilo asynchronous operational node using Restate as the authoritative durable outer runtime and ordinary maintained Pi as the first replaceable coding-agent driver: place the implementation in the natural Kilo-owned integration boundary without modifying Restate or Pi core; provide stable operation identity, Pi process/session control, pre-effect Restate gates, Restate-owned tool effects, structured lifecycle visibility, semantic settlement, restart recovery and bounded cancellation/child control; and execute the complete acceptance matrix so every independent requirement returns PASS, FAIL or BLOCKED rather than terminating the run at the first residual.

The complete normative handoff and acceptance checklist are preserved verbatim in [`GOAL.md`](GOAL.md); identity hash: `71bd4e04e121b1473d384f7a92ce7c4c419968d3968169ff3253f3c39d5ee406`.
