# Lineage

- Goal: 2026-10-07-interactive-debug-v0
- Active subject: operational-node (physical code path: /home/miles/repos/agent-harnesses/kilo-restate/operational-node)
- Parent accepted mechanisms: HEADLESS Factory route from 2026-10-07-first-normal-factory-route; native interactive runtime/control physics from 2026-10-06-kilo-control-actor-physics and 2026-10-06-kilo-control-launch-attach.
- Current attempt: subject operational-node / iteration 001.
- Consolidation/freeze: not decided; preserve accepted existing route.
