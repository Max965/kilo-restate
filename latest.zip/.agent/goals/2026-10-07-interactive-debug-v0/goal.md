# Goal: Kilo OperationalNode INTERACTIVE_DEBUG V0

Preserve the accepted same-host DEV HEADLESS Factory route and deliver a canonical opt-in INTERACTIVE_DEBUG realization. A stakeholder must run one exact command in a VS Code terminal and enter native Pi InteractiveMode for the one Restate-owned OperationalNode; Kilo Control and Restate must identify/control the same Pi actor. Do not use the stakeholder as startup debugger.

Source settlement, implementation, physical terminal/TUI exercise, Kilo gates/effects/control, Restate and native Pi evidence correlation, injected actor failure/re-entry, Control cancellation, Pi Legacy fallback after terminal settlement, regression verification, cleanup, bounded review, and a minimal operator recipe are required. Retain limitations honestly; PARTIAL if a persistent terminal-management subsystem or other forbidden architecture is required.

Accepted world: see current iteration instructions and earlier accepted evidence under .agent/goals/2026-10-06-kilo-control-actor-physics/ and .agent/goals/2026-10-07-first-normal-factory-route/. This goal does not reopen those accepted HEADLESS/control semantics.
