# Current State

Active subject: `operational-node`, iteration `001`.

## Status

**ACHIEVED for the rebased INTERACTIVE_DEBUG V0 goal.** The retained Kilo implementation adds opt-in `INTERACTIVE_DEBUG` to the existing Factory/OperationalNode route. Default HEADLESS is preserved. Same-operation crash/re-entry after 239s, one-owner process replacement, native Restate inactivity configuration, Control cancellation, terminal-disconnect cancellation, native `/quit`, transcript projection, metadata-only DEBUG, exact no-export launcher, successful ACHIEVED→COMPLETED consumer specimen, and Pi Legacy fallback have physical evidence.

## Explicit boundary

The factory-dev-v0 authority remains trusted same-host DEV shell authority, not an OS/filesystem/network sandbox. No Bash parser or sandbox was added. Production confinement, cross-host recovery, worker-host crash cleanup, and arbitrary external-effect exactly-once semantics remain unclaimed.

## Source and test state

Product changes are uncommitted in `/home/miles/repos/agent-harnesses/kilo-restate` under `operational-node/`. Final targeted checks and output are in `subjects/operational-node/iterations/001/evidence/physical/validation-final.log`; consumer result is in `consumer-test-final.log`. Full matrix and explicit release review: see `REPORT.md` and the iteration `ACCEPTANCE-MATRIX.md`.

The disposable Restate deployment/container, worker, Control socket/grants, and test listeners have been removed. No Pi/PTY test processes remain. Accepted services and the completed Factory release/ZIP remain unchanged. `PI_LEGACY` and `SMITHERS` remain explicit routes; no silent fallback was added.
