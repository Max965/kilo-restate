# Subject: operational-node

Physical artefact: /home/miles/repos/agent-harnesses/kilo-restate/operational-node.

Allowed: minimal retained changes needed for explicit INTERACTIVE_DEBUG on the existing OperationalNode Factory path, using native Pi TUI, same Kilo extension and existing Restate workflow/control. HEADLESS remains default. Goal-local tests/evidence/operator recipe are allowed.

Frozen: Kilo Factory/OperationalNode semantics, deterministic admission/gating, effect/result semantics, Kilo Control authorization and accepted HEADLESS behavior. Do not change Pi or Restate cores, accepted unrelated demo service/workspaces, production security, or user/global provider credentials/config. Do not add terminal manager, broker, database, daemon, workflow engine, second Pi owner, or mandatory tmux/Herdr.
