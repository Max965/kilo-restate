# First-use bootstrap repair — 2026-10-08

RESULT: ACHIEVED

## Root cause

The maintained `/home/miles/.local/bin/kilo` wrapper delegated to tracked `bin/kilo`, whose persistent `~/.config/kilo/operational-node.env` still exported:

- `/tmp/kilo-interactive-ready-20261007/control.sock`
- `/tmp/kilo-interactive-ready-20261007/token`

That disposable `/tmp` ownership had already been cleaned. The failure was therefore a stale cleaned-up disposable credential/configuration, not a Factory admission, capability-policy, workspace-authority, or Pi-profile problem. The reported `ENOENT ... stat .../token` occurred before Control admission and before any Pi TUI could start.

## Repaired boundary

Restored the existing native commissioning mechanism with a new owned persistent DEV state directory:

```text
/home/miles/.local/state/kilo-control/bootstrap-20261008/
```

It contains a private socket, token, grants file, and Pi session root. Permissions were verified as directory `0700`, token/grants/socket `0600`; token contents were never printed.

The existing bare `kilo` wrapper and tracked `bin/kilo` were preserved. Only `~/.config/kilo/operational-node.env` was updated to point at the owned state directory. No dummy token, auth relaxation, shell sandbox, or new runtime was introduced.

The owned service is:

```text
kilo-control-bootstrap-20261008.service
```

It runs the existing `operational-node/restate/service.ts` on port `39360`, uses the existing Restate DEV ingress/admin `18190/19180`, and registers deployment `dp_10KoLozBFK8tAvA2BiuuU4V`. Deployment metadata confirms KiloPiOperation revision 3 and the native Restate inactivity configuration.

## Authority/profile verification

The service is configured with:

- workspace root: `/home/miles/repos/agent-sandbox`
- maintained Pi source: `/home/miles/repos/agent-harnesses/kilo-pi-durable`
- scoped Pi profile: `/home/miles/repos/runtime/.pi/agent`
- Kilo Control grant workspaces: `/home/miles/repos/agent-harnesses/kilo-restate` and the disposable proof workspace
- explicit capabilities: VIEW, ATTACH, INSPECT, DEBUG, STEER, CANCEL, LAUNCH

No workspace policy was widened beyond the existing admitted root.

## Original Factory identity

The downloaded work package compiled to:

```text
factory-5676d57123210f41881c5ea23373079ad4cfdbd3
```

with semantic address:

```text
kilo-control-permissions-lineage-selfhost-20261008/factory/iteration-01
```

The authoritative Restate status query returned `not_found`; the original work identity was not admitted and had not started. The original downloaded work package was preserved unchanged. Safe decision: do not retry it automatically or duplicate it; the stakeholder may retry the original script now that bootstrap is repaired.

## Physical proof

A separate disposable work package/workspace was launched from a fresh ordinary shell with no manually exported Control or Restate variables:

```text
kilo factory --interactive /tmp/kilo-bootstrap-work-package.json
```

The native Pi TUI appeared. It:

1. Read `TASK.md`.
2. Created `bootstrap-proof.txt` containing exactly `KILO_BOOTSTRAP_READY`.
3. Ran the prescribed bounded Node verification successfully.
4. Returned a six-field WorkReport with `RESULT: ACHIEVED`.
5. Exited through native `/quit`.
6. Returned the outer command with durable node completion.

Kilo Control HERE observed the same node while it was running:

- operation: `factory-9574967f0a258701887c85723593976dc9cc862b`
- session: `5917a61b-22c7-4e37-93a5-88690f428d8a`
- attempt: `42cfc02c-4435-467e-8764-131fa05280d7`
- Pi PID: `201554`
- status at live inspection: `running`, one live owner

The final TUI output showed `RESULT: ACHIEVED` and `[node] completed`. The disposable proof workspace was separate from the canonical source worktree; no concurrent source writer was started.

## Service state

The repaired owned service and existing Restate container remain running for the stakeholder's next Terminal 2 retry:

```text
systemctl --user is-active kilo-control-bootstrap-20261008.service  # active
podman container: kilo-run-55ca2314-restate                  # running
```

This is deliberate: removing the service or state directory would recreate the stale-token failure. Cleanup after the stakeholder trial must remove only this owned unit, deployment `dp_10KoLozBFK8tAvA2BiuuU4V`, state directory, and disposable proof workspace; preserve the existing accepted Restate/container resources as appropriate.

## Regressions

Existing targeted checks remain the current closure baseline and passed previously:

- `npm run typecheck:operational-node`
- `npm run test:operational-node`
- `npm run test:daily`
- `npm run test:control`
- `npm run test:interactive-debug`

No source files were changed for this bootstrap repair. The repair is configuration/owned-service state only.
