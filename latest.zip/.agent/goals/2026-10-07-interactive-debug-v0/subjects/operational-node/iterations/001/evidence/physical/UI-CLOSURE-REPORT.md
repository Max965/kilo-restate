# Restate Native UI closure probe

RESULT: ACHIEVED
NATIVE_UI_READY_FOR_DEBUG: YES
RESTATE_VERSION: 1.7.13
WEB_UI_VERSION: native Restate 1.7.13 UI (title `Restate - Overview`)
VERIFIED_LOCAL_UI_URL: http://127.0.0.1:19180/ui/overview

## Smallest improvement

NONE to OperationalNode production code. The native UI already exposes the durable atoms required for basic debugging. A native configuration/semantic projection change would duplicate truth or require a Restate UI fork. Operator-facing instructions were tidied in `OPERATOR-UI-GUIDE.md`.

## Browser evidence

Real headed browser inspection captured:

- `restate-ui-overview.png`: Overview, Services, Deployments, Invocations, Running/In-flight/Held up/All, Workflows, Virtual Objects, State, Introspection and Query inspector; Kilo services visible with deployment revision.
- `restate-ui-invocation-detail.png`: invocation detail, target, deployment, linked workflow run, linked KiloOperationEvents virtual object, Journal tab, Input/Result/State/Value expandable entries.

Exact native deep link:
`http://127.0.0.1:19180/ui/invocations/inv_1b7aotAkrz0433NZrg852HkV8bn3buzu03`

## Correlation specimen

- Factory / semantic identity: `interactive-ready-consumer`, `interactive-ready-slugify`, `iteration-01`; address workspace `/home/miles/repos/agent-sandbox/kilo-interactive-debug-ready-20261007`, role `factory`.
- OperationalNode: `factory-2b81af1d1dae95f7937a50d681fceae4b8473703`, status `completed`.
- Restate invocation: `inv_1b7aotAkrz0433NZrg852HkV8bn3buzu03`, target `KiloPiOperation/factory-2b81af1d1dae95f7937a50d681fceae4b8473703/run`, native status `completed`, journal size 19.
- Pi: session `80fb8920-5d54-439e-b285-ec4af8ead72d`, native session JSONL under the configured session root, actor outcome `normal`, Pi settlement `agent_settled`.
- Gate/effect identities: Kilo OperationEvents and native Restate Call/Run journal entries; exact semantic effect IDs remain Kilo-recorded, while invocation/journal causality is Restate-native.
- Result: WorkReport `ACHIEVED`, Control inspection `COMPLETED`, independent consumer test `interactive consumer: PASS`.

## Capability boundary

Native Restate shows/query-provides service/handler, deployment, invocation ID/target/status/timestamps, journal entries, workflow/object links, state/result/input expansion, and native SQL/Admin query results. Existing Kilo semantic identity is visible only through existing Input/State/Result JSON or Kilo Control; it is not a native semantic column/group/navigation relation. Pi transcript/session content is PI_NATIVE and is not a Restate UI atom.

No Restate UI fork, server fork, custom dashboard, projection database or telemetry platform was added. Basic debug does not require a fork. A future upstream UI-only change could add metadata-aware filters/deep links, but is not justified for this bounded probe.
