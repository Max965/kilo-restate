# OperationalNode atoms and relations

| Edge / atom | Truth location | Evidence |
|---|---|---|
| Factory identity → operation/address | KILO_RECORDED | Existing workflow state: `factoryIdentity`, `factoryWorkspace`, semantic address. Control inspect and successful specimen. |
| Operation → Restate invocation | RESTATE_NATIVE + KILO_RECORDED | Native invocation `inv_1b7aotAkrz0433NZrg852HkV8bn3buzu03`, target `KiloPiOperation/factory-2b81.../run`; native SQL and UI detail. |
| Invocation → journal Run/Call/Output | RESTATE_NATIVE | Native journal query: 19 entries including validate-workspace, `ordinary-pi-rpc-turn`, calls and Output; UI Journal tab renders these entries. |
| Invocation → Pi session | KILO_RECORDED + PI_NATIVE | Existing OperationResult identity/sessionFile and native Pi JSONL at `/tmp/kilo-interactive-ready-20261007/sessions/...`. |
| Pi tool proposal → gate | KILO_RECORDED / RESTATE_NATIVE | Kilo OperationEvents records `tool_requested`, gate events and gate identity; Restate journal records calls to gate workflow. |
| Gate → effect | RESTATE_NATIVE + KILO_RECORDED | Gate/effect invocation and journal calls are native; Kilo events carry effect identity and operation. |
| Effect → result | RESTATE_NATIVE + KILO_RECORDED | ToolEffect journal/effect events plus typed OperationResult. |
| Final typed result | KILO_RECORDED | Existing workflow result and Control inspection show `ACHIEVED`, `agent_settled`, `normal`, `COMPLETED`. |
| Subject/goal → responsibility/report_to relation | KILO_DERIVED at best | The semantic address and Factory identity are stored in workflow state/input. Restate does not natively render a Factory ontology or causal `report_to` edge. |
