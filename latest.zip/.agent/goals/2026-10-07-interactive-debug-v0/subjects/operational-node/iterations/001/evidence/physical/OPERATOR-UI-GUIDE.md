# Restate Native UI debugging guide

## Terminals

**Terminal 1 — fallback only**

```sh
pi
```

Keep ordinary Pi idle unless the OperationalNode is terminal. Use the fallback worktree only after authoritative cancellation/completion and no live owner.

**Terminal 2 — OperationalNode**

```sh
cd /home/miles/repos/agent-sandbox/kilo-interactive-debug-ready-20261007
kilo factory --interactive /tmp/kilo-interactive-ready-20261007/work-package.json
```

This is the exact verified no-export route. Native Pi TUI appears in the terminal. `/quit` is normal Pi shutdown; `kilo node cancel <responsibility>/factory/iteration-01` is durable Kilo cancellation.

**Terminal 3 — optional Kilo Control**

```sh
cd /home/miles/repos/agent-sandbox/kilo-interactive-debug-ready-20261007
kilo node here
kilo node inspect interactive-ready-slugify/factory/iteration-01 --json
kilo node attach interactive-ready-slugify/factory/iteration-01
kilo node debug interactive-ready-slugify/factory/iteration-01 provider-request
kilo node steer interactive-ready-slugify/factory/iteration-01 'bounded correction'
kilo node cancel interactive-ready-slugify/factory/iteration-01
```

The wrapper loads the owned local Control endpoint/token configuration. The operator does not reconstruct socket/token identifiers.

## Browser

Verified local URL:

```text
http://127.0.0.1:19180/ui/overview
```

Observed server: Restate `1.7.13`; UI title: `Restate - Overview`.

1. Open **Invocations → All**.
2. Select the `KiloPiOperation` service tab, or use the invocation ID field.
3. Open the exact durable invocation:
   `http://127.0.0.1:19180/ui/invocations/inv_1b7aotAkrz0433NZrg852HkV8bn3buzu03`
4. The detail page shows target `KiloPiOperation/factory-2b81.../run`, deployment, linked workflow run, linked `KiloOperationEvents` virtual object, journal timeline, and expandable Input/Result/State/Value entries.
5. Use the **Journal** tab to inspect `validate-workspace`, `ordinary-pi-rpc-turn`, `Call`, `Run`, and `Output`. Use **Workflows**, **Virtual Objects**, **State**, and **Query inspector** for native Restate navigation.

The native UI proves durable invocation/journal/state/call relations. It does not provide Factory subject/goal/workspace/responsibility columns, Pi transcript rendering, typed WorkReport fields as dedicated columns, or Kilo gate/effect semantic grouping. Expand existing Input/State/Result JSON or use the native query inspector/Admin API.

## Native query equivalents

```sh
curl -sS -X POST http://127.0.0.1:19180/query \
  -H 'content-type: application/json' -H 'accept: application/json' \
  --data '{"query":"SELECT id, target, target_service_name, target_service_key, target_handler_name, invoked_by, journal_size, created_at, completed_at, status, completion_result FROM sys_invocation WHERE id = '\''inv_1b7aotAkrz0433NZrg852HkV8bn3buzu03'\''"}'

curl -sS -X POST http://127.0.0.1:19180/query \
  -H 'content-type: application/json' -H 'accept: application/json' \
  --data '{"query":"SELECT id, index, entry_type, name FROM sys_journal WHERE id = '\''inv_1b7aotAkrz0433NZrg852HkV8bn3buzu03'\'' ORDER BY index"}'
```

Use Kilo Control for semantic identity/result and the Pi session JSONL for actor/transcript evidence. Do not infer Pi thinking/token streaming or Factory `report_to` relations from Restate.

## Safe fallback

```sh
kilo node cancel <responsibility>/factory/iteration-01
kilo node inspect <responsibility>/factory/iteration-01 --json
# only after status=cancelled/completed and live=null:
cd <same-worktree>
pi
```

## Native UI limitation

No new UI was added. The exact missing presentation is semantic grouping/navigation from Factory identity and Kilo Control address directly into native Restate invocation/journal screens. Today the operator uses the stable invocation deep link from Control inspect/result or the native invocation ID field. A future upstream Restate UI enhancement could add read-only metadata columns/links; a fork is not justified for basic debugging.
