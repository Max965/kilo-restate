# INTERACTIVE_DEBUG V0 operator recipe

**Same-host development only. Do not use for untrusted work.** The observed `cd .. && pwd` Bash probe ran outside the authorized workspace; this route is not an OS/network sandbox.

## Preconditions

- The existing Kilo OperationalNode worker is deployed to the existing Restate instance and its private Control Unix socket is live.
- The operator has a private `0600` Control token file and a grant authorized for `LAUNCH`, `ATTACH`, `STEER`, and `CANCEL` in the package workspace. Add `DEBUG` only when the package loads the debug extension.
- The workspace is absolute and the actor provider/model are explicit. No user/global provider configuration changes are required.

## Work package

Add this exact opt-in field to a valid Factory work package; omitting it remains `HEADLESS`:

```json
"REALIZATION": "INTERACTIVE_DEBUG"
```

Keep the existing `factory-dev-v0` authorization and workspace binding. Do not put credentials in the package.

## Launch

From the Kilo repository in a real terminal:

```sh
KILO_CONTROL_SOCKET=/path/to/private/control.sock \
KILO_CONTROL_TOKEN_FILE=/path/to/private/control-token \
npm run --silent node:daily -- factory --interactive /absolute/path/to/work-package.json
```

The command enters native Pi InteractiveMode in that terminal. Type normally; `/quit` exits Pi. A valid `ACHIEVED` WorkReport and normal Pi exit are both required for successful completion. `PARTIAL`/`BLOCKED` are preserved as semantic failure; they are not relabeled as success. Closing the attached terminal cancels an admitted, unsettled operation.

## Observe or control the same node

Run these from the package workspace; the selector is `responsibility/role/instance`:

```sh
bin/kilo node here
bin/kilo node inspect <responsibility>/factory/iteration-01 --json
bin/kilo node attach <responsibility>/factory/iteration-01
bin/kilo node debug <responsibility>/factory/iteration-01 provider-request
bin/kilo node steer <responsibility>/factory/iteration-01 'short direction'
bin/kilo node cancel <responsibility>/factory/iteration-01
```

`ATTACH` projects Pi transcript messages; `DEBUG` exposes only metadata/counts/field names/hashes. `STEER` enters the native Pi editor. Control and Restate reference the same operation/invocation/session; do not launch a second owner for an existing operation.

`PI_LEGACY` and `SMITHERS` remain explicit, separate Factory routes. This change does not silently fall back or retry a settled Kilo operation through Pi Legacy; select the explicit route for a new attempt. Existing route/reconciliation evidence remains under `.agent/goals/2026-10-07-first-normal-factory-route/` and the accepted Software Factory release.
