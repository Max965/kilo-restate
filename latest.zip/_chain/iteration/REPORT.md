FACTORY_REBASE_REQUIRED: software-factory
RECEIVER_ACTION: Read exact ITERATION.md before judging/adopting; this report is evidence-only
REPORT_TIMESTAMP: 2026-10-06T17:44:47+01:00
GOAL_ID: 2026-10-06-kilo-control-v0
ITERATION: 01
RUN_KIND: IMPLEMENTATION
GOAL_BATCH_MODE: NONE
EXECUTION_MODE: PI_LEGACY
PI_REVIEW_PROFILE: DIRECT
WORKER_RESULT: AGREES
RESULT: ACHIEVED
SEMANTIC_RETURN_POINT: REACHED
POST_RETURN_POINT_SUBJECT_ACTIONS: NONE
WAKE_CONTROL_AUDIT: N/A
ASYNC_WORK_SHAPE: foreground specimens; no new completion loops
UNAUTHORISED_WAKE_REENTRIES: NONE
ORCHESTRATION_TERMINAL_CLASS: RETURN_PASS
RETURN_ENVELOPE: KILO_CONTROL_V0_TERMINAL_PROOF
FACTORY_STATUS: external adoption/reconciliation only; no controller ledger mutation
TRACE_RECONCILIATION: PARTIAL (opening source/skill/admission order and task-claim timing incomplete; not retrospectively certified)
SOURCE_CONTROL_BASE_HEAD: 22a0522803deddde6a32d0ab550e70631b881f60
SOURCE_CONTROL_END_HEAD: 22a0522803deddde6a32d0ab550e70631b881f60
COMMITS_AFTER_BASELINE: 0
RETURN_SOURCE_STATE: accepted dirty candidate plus bounded Control V0 seam; uncommitted review candidate
RECEIVED_INSTRUCTION_SHA256: 22180dec041666e75ff8767cf3337bdd0fe50ea056b0c0fdc30b12715f0e1497

# Kilo Control V0 — ACHIEVED

**Primary answer: yes, this bounded local control seam remains a thin in-owner adapter.** All17 physical checks passed. No new Pi/RpcClient, lifecycle, broker, registry database, durable semantic log, tail buffer or UI framework was needed. This is not production/untrusted-user authentication or a general Factory runtime.

## Architecture actually implemented

```text
existing Restate service process
  -> existing sole RpcClient owner
       -> native onEvent
       -> ephemeral per-operation EventEmitter fan-out
  -> opt-in private Unix HTTP command/SSE endpoint in that same process
       -> token capability + canonical workspace boundary
       -> native workflow query/status for semantic address selection
       -> existing native steer/cancel/submit
       -> Pi persisted transcript + Restate state/result catch-up
  -> ordinary terminal CLI projection / structured JSON
```

Addresses are optional metadata in **existing native workflow state**; no independent registry is persisted. Old unaddressed callers and all original ownership remain valid. Parent-run native query plus status discovers addresses; live map only describes already-owned current RpcClient attempts, never starts/replaces one. Provider/model SDK/core unchanged.

Transport: private Unix socket HTTP POST `/command`, one-way SSE POST `/events`. No listening control TCP port, broker, WebSocket framework, separate daemon or remote auth service. Socket path max100 bytes prevents Linux silent truncation; socket parent0700, socket0600, grant/token files0600. Local startup does not install global credentials/integration.

## Commands/API

The CLI spelling supports `kilo node ...` through a local function; no global installation:

```sh
export KILO_CONTROL_SOCKET=/tmp/<owned-private-directory>/control.sock
export KILO_CONTROL_TOKEN_FILE=/path/to/private-owner-token
kilo() { node --import /home/miles/repos/agent-harnesses/kilo-restate/node_modules/tsx/dist/loader.mjs /home/miles/repos/agent-harnesses/kilo-restate/operational-node/control-cli.ts "$@"; }
cd <admitted-workspace>
kilo node here
kilo node list --json
kilo node launch launch.json --json
kilo node attach proof/worker/alpha
# Ctrl-C detaches this observer only.
kilo node attach proof/worker/alpha
kilo node inspect proof/worker/alpha --json
kilo node debug proof/worker/alpha provider-request
kilo node steer proof/worker/alpha 'Bounded correction'
kilo node cancel proof/worker/beta
```

Bootstrap enables `KILO_CONTROL_SOCKET`/`KILO_CONTROL_GRANTS` on an **owned existing service process**, not a new control runtime. `launch.json`: address {workspace,responsibility,role,instance}, prompt, provider/model, optional native pi and opt-in debug. Protocol `/command` JSON: action VIEW/INSPECT/STEER/CANCEL/LAUNCH, selector/spec/message. `/events`: action ATTACH/DEBUG, selector, optional DEBUG layer context/provider-request. Every request is authenticated and workspace/capability checked at endpoint, not the CLI. IDs are detailed/JSON data, never required to select a normal node.

## Permission behavior

Static local grant maps bearer token to identity/capabilities/canonical workspaces. Actor identity is derived from credential, not request assertions. Owner had all seven permissions; viewer only VIEW/ATTACH. Direct protocol requests from viewer received **403 permission denied: CANCEL** and **403 permission denied: DEBUG**. Alpha continued and completed, proving denial did not cancel it. Inspector and launch debug use their own capabilities; unknown credentials are rejected before discovery; DEBUG messages are filtered out of ATTACH.

This is deliberately a **local delegated-capability boundary**, not independent OS identities or a sandbox. Same-UID users with filesystem/owner-key access and existing unsigned Restate ingress are outside it. Fence raw ingress/OS authority separately before hostile clients; do not interpret this403 proof as global network/process authorization. Grants are immutable until service restart, no remote provisioning/revocation stack.

## Semantic selector behavior

Minimum address: canonical workspace + responsibility/role/instance. CLI cwd supplies workspace; `proof/worker/alpha` is sufficient. Partial `proof/worker` is allowed as a filter, but INSPECT/ATTACH/control fail **409 ambiguous: proof/worker/beta, proof/worker/alpha** when two matches exist. Absent responsibility returns **404 no matches**. VIEW empty list is explicit. No UUID guessing or silent newest-match selection.

Actual two-node active human output:

```text
proof/worker/alpha running
proof/worker/beta running
```

JSON list and inspect are retained (`cli-list.txt`, `cli-inspect.txt`) and include machine operation/session/attempt identity when useful.

## Terminal / VS Code physical specimen

This was an **automated CLI specimen from the existing VS Code-integrated-terminal-parented Pi harness**, not a fabricated GUI or installed extension. `terminal-ancestry.json` records TERM_PROGRAM=vscode and Python/Bash→Pi→Bash→Code ancestry. Each client was launched with cwd exactly the admitted workspace; stdout captured for proof. The final `specimen.ts` launched Alpha through the actual production CLI, used here at active state, and ran the production attach CLI, SIGINT-disconnect and reconnect while Pi continued. No keyboard/UI automation or new VS Code extension.

First live attach:

```text
[catch-up proof/worker/alpha] running

[pi] turn_start

[assistant]
LIVE_ALPHA: preparing the harmless read.
{
  "status": "detached"
}
```

Reconnect (excerpt, full transcript retained):

```text
[catch-up proof/worker/alpha] running
[user/text] Before any tool, say LIVE_ALPHA: preparing the harmless read. Then read probe.txt exactly once and return its marker. No changes or other tools. This is a bounded control proof.
[assistant/text] LIVE_ALPHA: preparing the harmless read.

[tool catch-up] read {"path":"probe.txt","offset":null,"limit":null}
[kilo] {"type":"gate_pending","at":"2026-10-06T16:28:36.670Z","toolCallId":"call_k8CTxHTKABbEitw0Xl9SVtaU|fc_09a26261148a9b33016ac521b3ec3487d299aa1cb123cab1b4"}
[kilo] {"type":"gate_allowed","at":"2026-10-06T16:28:39.868Z","toolCallId":"call_k8CTxHTKABbEitw0Xl9SVtaU|fc_09a26261148a9b33016ac521b3ec3487d299aa1cb123cab1b4"}
[kilo] {"type":"effect_started","at":"2026-10-06T16:28:40.211Z","toolCallId":"call_k8CTxHTKABbEitw0Xl9SVtaU|fc_09a26261148a9b33016ac521b3ec3487d299aa1cb123cab1b4","operation":"access","effectId":"effect_2e54086a90a501a73642682b01eb2adfc812a2b0"}
[kilo] {"type":"effect_completed","at":"2026-10-06T16:28:40.549Z","toolCallId":"call_k8CTxHTKABbEitw0Xl9SVtaU|fc_09a26261148a9b33016ac521b3ec3487d299aa1cb123cab1b4","operation":"access","effectId":"effect_2e54086a90a501a73642682b01eb2adfc812a2b0"}
[kilo] {"type":"effect_started","at":"2026-10-06T16:28:40.876Z","toolCallId":"call_k8CTxHTKABbEitw0Xl9SVtaU|fc_09a26261148a9b33016ac521b3ec3487d299aa1cb123cab1b4","operation":"detectImageMimeType","effectId":"effect_0875c5026cb40d85088592817475387a558be311"}
[kilo] {"type":"effect_completed","at":"2026-10-06T16:28:41.144Z","toolCallId":"call_k8CTxHTKABbEitw0Xl9SVtaU|fc_09a26261148a9b33016ac521b3ec3487d299aa1cb123cab1b4","operation":"detectImageMimeType","effectId":"effect_0875c5026cb40d85088592817475387a558be311"}
[kilo]
```

Final output included the fixture marker and authorized steer marker `STEERED_eb237d54-52a6-4588-bbbc-9f7b6dab2d80`. Alpha completed; Beta's authorized cancellation settled `cancelled`. Post-settlement INSPECT returned both actual native Pi messages and actual Restate result/state. `final-alpha.json`, `final-beta.json`, terminal transcripts and JSON CLI outputs are exact evidence.

## Process/RpcClient ownership

- Alpha operation: `control-524289fb-68d8-4328-922f-efb96448043c`
- Session: `fd5cbd0a-b318-4f04-a4ba-ede4ce611bea`
- Driver attempt: `5db571dc-dccd-4507-bf20-71579e3f0b4d`
- RpcClient owner process: `732591`
- Actual Pi process: `732799`
- Native pi_process_started count: **one**.
- Before disconnect and after reconnect: same attempt/session and still-running state.

Subscription only installs/removes emitter listeners. It never invokes RpcClient.start/stop, prompt, session reopen or a second constructor. Existing native driver is still the only constructor/owner; existing Restate steer/cancel routes remain in use. `before-disconnect.json`/`after-reconnect.json`/`reconnect-gap.json` plus native state/session prove this. Beta is another intentionally launched node, not an observing duplicate of Alpha.

## Catch-up/reconnect

The disconnect gap missed **11 tool-call deltas**. Native persisted transcript recovered the completed announcement and full tool proposal (3 messages); renderer shows `[tool catch-up] read ...`. No real semantic gap needing a separate buffer remained for this specimen, so **no in-memory tail** was added.

Live transcript pointer comes from actual pi_process_started when workflow identity still says `pending`; terminal pointer comes from native identity. The API reads those native files and Restate state, not a mirror. Exact replay of an unfinished token chunk before Pi persists its message is not promised. Catch-up capped2MiB, slow-client queued output capped1MiB; disconnect requires reconnect/history rather than blocking the RpcClient owner. Annotation poll500ms per viewer is bounded DEV tax; semantic deltas never traverse Restate.

## Deep debug

Opt-in `control-debug.ts` registers native context_with_system and before_provider_request hooks. Documented `ctx.ui.notify` emits metadata through ordinary RPC notifications already received by owner. DEBUG sees only validated layers, request/message counts, payload field names and SHA256; no headers, tokens, context/prompt/payload bodies. Driver validates/whitelists debug projection, and ATTACH receives none.

Final specimen had four privileged context/provider-request debug records (two model requests). Metadata sample:

```json
{
  "operationId": "control-524289fb-68d8-4328-922f-efb96448043c",
  "sessionId": "fd5cbd0a-b318-4f04-a4ba-ede4ce611bea",
  "attemptId": "5db571dc-dccd-4507-bf20-71579e3f0b4d",
  "ownerPid": 732591,
  "at": 1791304113298,
  "kind": "debug",
  "event": {
    "layer": "provider-request",
    "sha256": "91012382b06288903bc7842bf3fd8cdcae8e876b4ea94f8f700371949ad82d59",
    "request": 1,
    "fields": [
      "model",
      "store",
      "stream",
      "instructions",
      "input",
      "text",
      "include",
      "prompt_cache_key",
      "tool_choice",
      "parallel_tool_calls",
      "tools",
      "reasoning"
    ]
  }
}
```

Normal RPC supplies lifecycle/messages/tools/settlement; observer extension contributes only otherwise unavailable debug seams. Thinking renderer is runnable-tested; this trivial Sol/low specimen emitted zero thinking/reasoning tokens, so no physical thinking text was invented. If Pi emits thinking_delta it renders through same path.

## Machine/JSON and acceptance

Normative `evidence/acceptance.json`, run `.agent/goals/2026-10-06-kilo-control-v0/iterations/01/evidence/run-1791304105959`:

| Check | Result |
|---|---|
| workspace_active_semantic_discovery | PASS |
| zero_explicit | PASS |
| ambiguous_explicit | PASS |
| live_text_in_terminal | PASS |
| reconnect_same_attempt_session | PASS |
| one_rpc_process_attempt | PASS |
| authorized_inspect | PASS |
| authorized_steer_consumed | PASS |
| authorized_cancel | PASS |
| reader_cancel_denied_at_boundary | PASS |
| reader_debug_denied_at_boundary | PASS |
| privileged_safe_debug | PASS |
| attach_excludes_debug | PASS |
| pi_and_node_settlement | PASS |
| json_machine_list | PASS |
| catchup_complete_proposal | PASS |
| native_result_and_transcript | PASS |

All17 pass, current new and legacy contract/demo/Daily Driver tests and typechecks pass. Probe resources were separately owned and removed; prior successful demo remained active/untouched. No provider/auth/core or dependency changes, no commits/promotion/Factory ledger.

## Retained files/LOC and seam classification

New product files (physical LOC, formatting is dense; byte counts expose actual size):

| File | LOC | Bytes | Seam |
|---|---:|---:|---|
| operational-node/control-policy.ts | 19 | 1917 | NATIVE_NECESSARY |
| operational-node/control-live.ts | 7 | 700 | NATIVE_NECESSARY |
| operational-node/control-debug.ts | 6 | 685 | NATIVE_NECESSARY |
| operational-node/control.ts | 65 | 8759 | NATIVE_NECESSARY |
| operational-node/control-cli.ts | 40 | 4741 | NATIVE_NECESSARY |

**137 new production physical lines /16,802 bytes**, plus existing integrations: contract+2/-0, driver+20/-2, service+7/-1. Total new production166 added/3 removed lines; tests19 lines; additive README26 and npm+3/-1. Not a hidden generated framework: code is five small files and existing process callbacks. `retained-delta-loc.json` compares to the exact pre-Control source snapshot, not whole HEAD diff containing earlier accepted work.

- `control-policy.ts`: minimal address/selector/capability law — NATIVE_NECESSARY.
- `control-live.ts`: ephemeral in-owner fan-out/attempt metadata — NATIVE_NECESSARY.
- `control.ts`: local permission boundary/native query/SSE/native catch-up/commands — NATIVE_NECESSARY.
- `control-cli.ts`: terminal/JSON adapter — NATIVE_NECESSARY.
- `control-debug.ts`: opt-in metadata observer over documented native notify/RPC — NATIVE_NECESSARY; no rawstdout protocol invention.
- Existing driver tap + native-state address/status + optional service startup — NATIVE_NECESSARY.

No ESCAPE_HATCH or UNJUSTIFIED retained seam. NativeEmitter is not a broker/pubsub service. Native workflow state address is not a registry DB. Server shares existing process/lifecycle and does not own a new agent loop. No Herdr/Langfuse/DAP/TUI/VS Code extension, generalized remote auth, durable semantic event log or release mechanism.

## Preserved failed attempts and residuals

First run exit0 for core commands but failed debug/liveness expectations: pi.ui undefined (correctctx.ui), normal writable backpressure mistaken for stalled client. Second run exit1:140-byte Unix path silently collided at108-byte Linux sockaddr prefix with first stale socket; removed only exact known-owned socket, shortened private path, added max100 validation. These were local adapter defects, not reason to replace ownership. Later runs prove corrected stream/debug and catch-up; prior records remain.

Remaining limits: static local grants, pre-existing raw ingress not fenced, same-host owner/socket, 200-node native discovery scan and parent-run retention horizon, older unaddressed nodes not silently adopted, 2MiB transcript ceiling, 1MiB slow-consumer bound, unfinished token catch-up/restart/owner-transfer not guaranteed, repeated per-viewer annotation polls create ordinary native helper invocations. No claims of production remote auth, general multi-tenant resource security or exactly-once arbitrary external effect. These are bounded follow-ups, not new systems built here.

Process debt: initial trace/skill/gate/task-claim ordering imperfect; material actions reconciled and disclosed. Installed DIRECT closure/final-sweep gate reaches RETURN_PASS and exact handoff SHA re-verifies; late initialization is still debt, not original perfect compliance. DIRECT root completed distinct source/evidence/permission/ownership second pass, no delegation. No native completion notifications were created by these foreground specimens. Final work question reached; no further subject branch or promotion authorized.

## Final result

**ACHIEVED.** The workspace-local terminal workflow and authorized local control can remain a thin adapter over the same Restate/Pi owner. The exact final proof does not rely on UUID selection, a duplicate Pi, hidden event persistence or a new runtime. Current prior demo resources remain untouched; Kilo Control's new specimen resources were cleaned (no leave-running requirement for this work order).
