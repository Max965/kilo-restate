EXECUTION_MODE: PI_LEGACY  
PI_REVIEW_PROFILE: DIRECT

Do this work yourself; do not launch or delegate to any sub-agents.

SUBJECT_ROOT: /home/miles/repos/agent-harnesses/kilo-restate

GOAL: Implement and physically prove the smallest useful **Kilo Control V0** over the already-accepted Restate OperationalNode + Pi RpcClient architecture.

This is a bounded implementation experiment. The primary acceptance question is:

> Can workspace-local OperationalNode discovery, live Pi viewing, inspection/debug and authorized control remain a thin adapter rather than becoming another runtime/system?

### Freeze existing ownership

Restate remains:
- durable OperationalNode identity/lifecycle;
- gate/effect journal;
- recovery;
- settlement/result.

The existing Kilo Pi driver remains:
- sole owner of each live Pi RpcClient/process attempt;
- steer/cancel path.

Pi remains:
- semantic actor/session/transcript;
- live RPC semantic events;
- native provider/model/tool runtime.

Do not create a second Pi process/client to observe a node.

### Build only the missing Kilo Control seam

Implement the smallest coherent local control surface supporting the semantics:

```text
VIEW
ATTACH
INSPECT
DEBUG
STEER
CANCEL
LAUNCH
```

Permissions must be checked at the control boundary, not only in the CLI.

For this DEV specimen the current owner may have admin-equivalent permissions, but prove at least one lower-privilege identity/capability set is denied a prohibited operation.

### Semantic discovery

Normal human/agent selection must not require UUIDs.

Use the minimum semantic address:

```text
workspace
responsibility
role
instance
```

Resolve that address to the existing durable `operationId`.

Machine IDs remain available in detailed/JSON output.

Zero matches and ambiguous multiple matches must be explicit; never guess silently.

### Live relay

Fan out the Pi RPC events already received by the existing RpcClient owner.

Do not route text/thinking deltas through Restate.

Do not add a broker, database, durable semantic event log or second lifecycle.

Ordinary live attach should render at least:

- assistant/text updates;
- thinking updates where Pi exposes them;
- turn/lifecycle;
- tool request/execution/result;
- minimal Kilo gate/effect annotations;
- Pi settlement / node settlement.

A Pi observer extension may contribute deep debug events only for seams not available through normal RPC.

### Control protocol

Choose the smallest local/native transport.

Prefer a simple local command endpoint plus one-way event subscription if sufficient. Unix socket, local HTTP/SSE or WebSocket are implementation choices, not architectural commitments.

Do not build a general network service or remote multi-tenant auth stack in this increment.

### CLI / terminal projection

Provide one coherent CLI surface, exact spelling your judgement, with equivalent capabilities to:

```text
kilo node here
kilo node list
kilo node attach <semantic-selector>
kilo node inspect <semantic-selector>
kilo node debug <semantic-selector> [layer]
kilo node steer <semantic-selector> <message>
kilo node cancel <semantic-selector>
```

Human output should be concise and semantic.

Provide structured machine output (`--json` or equivalent) for list/inspect/status so another OperationalNode/agent can use the same control plane.

While attached, local slash-style control commands are acceptable if they remain Kilo Control commands rather than direct undocumented Pi manipulation.

### VS Code specimen

From an ordinary VS Code integrated terminal whose cwd is an admitted workspace:

1. discover active nodes for that workspace;
2. identify at least one node by semantic responsibility/role rather than IDs;
3. attach and see live Pi semantic activity;
4. disconnect;
5. reconnect while the same Pi continues;
6. prove no duplicate Pi process/RpcClient lifecycle was created;
7. perform an authorized inspect;
8. perform an authorized steer;
9. prove one unauthorized higher-privilege control is denied;
10. let the node settle and show useful post-settlement inspection using Pi transcript/session + Restate result.

If practical, use two overlapping bounded nodes to prove workspace/responsibility/role/instance disambiguation.

### Deep debug

Prove the control surface can optionally expose at least one low-level observer-extension event such as context/provider-request metadata under DEBUG permission.

Do not expose secrets, auth headers/tokens or unrestricted repository content.

Deep debug is opt-in and more privileged than ATTACH.

### Catch-up/reconnect

Do not build a durable event bus.

Use:

```text
catch-up = Pi persisted session/transcript + Restate durable state/result
live     = current RpcClient owner event fan-out
```

Add an in-memory tail buffer only if the physical reconnect test proves a real visible gap that requires it.

### Explicit non-goals

Do not:
- fork Restate UI;
- build a VS Code extension;
- adopt Herdr;
- adopt Langfuse;
- implement full Debug Adapter Protocol;
- add a registry database;
- add a broker/pubsub system;
- journal every semantic event into Restate;
- build production remote auth/multi-tenancy;
- redesign OperationalNode lifecycle;
- promote/release.

### Low-tax acceptance

Report retained production delta by file and LOC.

Classify each meaningful new seam:

```text
NATIVE_NECESSARY
ESCAPE_HATCH
UNJUSTIFIED
```

ACHIEVED requires the end-to-end terminal workflow above and a convincingly small retained architecture.

If the work naturally expands into a substantial daemon/event platform/state store/UI framework, stop and return PARTIAL with the physical reason instead of normalizing that complexity.

Return:

- architecture actually implemented;
- transport chosen and why;
- commands/API;
- permission behavior;
- semantic selector behavior;
- attach/reconnect evidence;
- process/RpcClient ownership evidence;
- deep-debug evidence;
- machine/JSON evidence;
- retained files + LOC;
- residual unknowns;
- RESULT: ACHIEVED | PARTIAL | BLOCKED.